# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, 
    QgsProcessingAlgorithm, 
    QgsProcessingParameterVectorLayer,
    QgsProcessingException,
    QgsGeometry,
    QgsFeature
)
import os

class UnirLinhasMesmaCamada(QgsProcessingAlgorithm):
    INPUT = 'INPUT'

    def tr(self, string): 
        return QCoreApplication.translate('Processing', string)
    
    def createInstance(self): 
        return UnirLinhasMesmaCamada()
    
    def name(self): 
        return 'unir_linhas_mesma_camada_individual'
    
    def displayName(self): 
        return self.tr('Emendar linhas')
    
    def group(self): 
        return self.tr('Ferramentas de camadas')
    
    def groupId(self): 
        return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\\\', '/')
        return f"""<html><body>
        <p>Este script une as linhas selecionadas <b>diretamente na camada original</b>.</p>
        <p><b>Diferencial:</b> Se os segmentos unidos não se tocarem, eles serão salvos como <b>feições individuais</b>, garantindo que não existam feições multipart.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT, 
                self.tr('Selecionar Camada de Linhas'), 
                [QgsProcessing.TypeVectorLine]
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)

        if layer is None:
            raise QgsProcessingException('Camada inválida.')

        selection = layer.selectedFeatures()
        
        if len(selection) < 2:
            feedback.pushInfo('Selecione ao menos duas linhas para emendar.')
            return {'SAIDA': 'Nenhuma alteração feita.'}

        layer.startEditing()
        
        geometria_unida = QgsGeometry()
        ids_para_remover = []
        primeira_feicao = selection[0]

        feedback.pushInfo(f'Processando {len(selection)} segmentos...')

        for feat in selection:
            if feedback.isCanceled():
                layer.rollBack()
                return {}

            if feat.hasGeometry():
                if geometria_unida.isNull():
                    geometria_unida = feat.geometry()
                else:
                    geometria_unida = geometria_unida.combine(feat.geometry())
            
            ids_para_remover.append(feat.id())

        # 1. Remove os segmentos antigos
        layer.deleteFeatures(ids_para_remover)

        # 2. Verifica se a geometria resultante é Multipart e separa as feições
        if geometria_unida.isMultipart():
            partes = geometria_unida.asGeometryCollection()
            feedback.pushInfo(f'A união resultou em {len(partes)} linhas separadas.')
            for parte in partes:
                nova_feicao = QgsFeature(layer.fields())
                nova_feicao.setGeometry(parte)
                nova_feicao.setAttributes(primeira_feicao.attributes())
                layer.addFeature(nova_feicao)
        else:
            nova_feicao = QgsFeature(layer.fields())
            nova_feicao.setGeometry(geometria_unida)
            nova_feicao.setAttributes(primeira_feicao.attributes())
            layer.addFeature(nova_feicao)

        feedback.pushInfo('Processo concluído. Verifique os segmentos e salve as edições.')

        return {'SAIDA': 'Linhas emendadas e separadas individualmente.'}