from qgis.core import (QgsProcessing, QgsProcessingAlgorithm, 
                       QgsProcessingParameterRasterLayer, QgsProcessingParameterFeatureSink)
import processing
import os

class SoloExposto(QgsProcessingAlgorithm):
    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer('INPUT', 'Imagem RGB (Entrada)'))
        self.addParameter(QgsProcessingParameterFeatureSink('OUTPUT', 'Vetor Solo Exposto'))

    def processAlgorithm(self, parameters, context, feedback):
        raster = self.parameterAsRasterLayer(parameters, 'INPUT', context)
        nome = raster.name()
        
        # 1. CONVERSÃO RGB PARA GLI
        gli = processing.run("qgis:rastercalculator", {
            'EXPRESSION': f'((2 * "{nome}@2" - "{nome}@1" - "{nome}@3") / (2 * "{nome}@2" + "{nome}@1" + "{nome}@3" + 0.0001))',
            'LAYERS': [raster], 
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']
        
        # 2. BINARIZAÇÃO AJUSTADA (Solo com tolerância a verde)
        # Aumentamos o limite para 0.05 para "ignorar" pequenos pontos verdes dentro do solo
        binarizado = processing.run("qgis:rastercalculator", {
            'EXPRESSION': f'("{gli}@1" <= 0.05) AND ("{gli}@1" != 0)',
            'LAYERS': [gli],
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']
        
        # 3. SUAVIZAÇÃO MÍNIMA (Sieve)
        suavizado = processing.run("gdal:sieve", {
            'INPUT': binarizado, 
            'THRESHOLD': 1, 
            'EIGHT_CONNECTEDNESS': True, 
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']
        
        # 4. POLIGONIZAÇÃO
        poligonos = processing.run("gdal:polygonize", {
            'INPUT': suavizado, 'BAND': 1, 'FIELD': 'DN', 'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']

        # 5. CÁLCULO DE ÁREA EM HA (Truncado em 2 casas)
        poligonos_area = processing.run("native:fieldcalculator", {
            'INPUT': poligonos,
            'FIELD_NAME': 'area_ha',
            'FIELD_TYPE': 0, 
            'FORMULA': 'floor(($area / 10000) * 100) / 100',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']

        # 6. FILTRO FINAL
        final = processing.run("native:extractbyexpression", {
            'INPUT': poligonos_area,
            'EXPRESSION': ' "DN" = 1 AND "area_ha" > 0 ',
            'OUTPUT': parameters['OUTPUT']
        }, context=context)['OUTPUT']

        return {'OUTPUT': final}

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""
        <html>
        <body>
            <h2>Solo Exposto</h2>
            <p>Este algoritmo identifica áreas de solo exposto, mesmo com presença leve de vegetação rasteira.</p>
            
            <p style="color: #2e7d32; font-weight: bold; margin-top: 10px;">
                Observação: Use os polígonos de talhões para melhor análise.
            </p>

            <div style="text-align: center; margin-top: 20px; margin-bottom: 20px;">
                <img src="file:///{icon_path}" width="250">
            </div>

            <p style="text-align: right; font-style: italic; margin-top: 30px; border-top: 1px solid #ccc; padding-top: 10px;">
                Desenvolvido por: <b>Paulo Vinicius da Silva</b>
            </p>
        </body>
        </html>
        """

    def name(self): return 'solo_exposto'
    def displayName(self): return 'Solo Exposto'
    def group(self): return 'Agricultura'
    def groupId(self): return 'agricultura'
    def createInstance(self): return SoloExposto()