from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsDistanceArea,
    QgsProject
)
from PyQt5.QtCore import QVariant
import os


class CalculoLinhasAgro(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                'INPUT',
                'Selecionar Linhas',
                [QgsProcessing.TypeVectorLine]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                'OUTPUT',
                'Cálculo de área linhas',
                createByDefault=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        source = self.parameterAsSource(parameters, 'INPUT', context)

        # 🔥 Configura cálculo de distância correto
        d = QgsDistanceArea()
        d.setSourceCrs(source.sourceCrs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        comprimento_total = 0

        for feat in source.getFeatures():
            geom = feat.geometry()
            comprimento_total += d.measureLength(geom)  # ✅ agora em metros reais

        # 🔥 Fórmula correta
        area_ha = (comprimento_total * 2) / 8000

        # Criar campo
        fields = QgsFields()
        fields.append(QgsField('area_ha', QVariant.Double, len=10, prec=2))

        # Criar saída temporária
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            'OUTPUT',
            context,
            fields,
            source.wkbType(),
            source.sourceCrs()
        )

        feat = QgsFeature(fields)
        feat.setAttributes([round(area_ha, 2)])

        sink.addFeature(feat)

        return {'OUTPUT': dest_id}

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Plugin para cálculo de área equivalente em hectares a partir de linhas</p>
        <p>Fórmula: (Comprimento total × 2) / 8000</p>
        <div style="text-align: center; margin: 20px 0;">
        <img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">
        Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def name(self):
        return 'calculo_area_linhas'

    def displayName(self):
        return 'Cálculo de Área Linhas'

    def group(self):
        return 'Agricultura'

    def groupId(self):
        return 'agricultura'

    def createInstance(self):
        return CalculoLinhasAgro()