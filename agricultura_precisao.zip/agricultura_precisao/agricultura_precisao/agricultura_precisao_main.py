import os
from qgis.core import QgsApplication
from .provider import AgriculturaPrecisaoProvider

class AgriculturaPrecisao:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        # A forma correta de registrar o provider no QGIS 3
        self.provider = AgriculturaPrecisaoProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        # Remove o provider ao desativar o plugin
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)