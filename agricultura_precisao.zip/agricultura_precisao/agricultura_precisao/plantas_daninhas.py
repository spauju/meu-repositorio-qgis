from qgis.core import (QgsProcessing, QgsProcessingAlgorithm, 
                       QgsProcessingParameterRasterLayer, QgsProcessingParameterFeatureSink)
import processing
import os

class IdentificacaoDaninhas(QgsProcessingAlgorithm):
    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer('INPUT', 'Imagem RGB'))
        self.addParameter(QgsProcessingParameterFeatureSink('OUTPUT', 'Resultado Daninhas'))

    def processAlgorithm(self, parameters, context, feedback):
        raster = self.parameterAsRasterLayer(parameters, 'INPUT', context)
        nome = raster.name()
        vari = processing.run("qgis:rastercalculator", {
            'EXPRESSION': f'((("{nome}@2" - "{nome}@1") / (\"{nome}@2" + "{nome}@1" - "{nome}@3" + 0.0001))) * 100',
            'LAYERS': [raster], 'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']
        stats = processing.run("qgis:rasterlayerstatistics", {'INPUT': vari}, context=context)
        limiar = stats['MEAN'] + (2.2 * stats['STD_DEV'])
        binario = processing.run("qgis:rastercalculator", {
            'EXPRESSION': f'("{vari}@1" > {limiar})',
            'LAYERS': [vari], 'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']
        binario_limpo = processing.run("gdal:sieve", {
            'INPUT': binario, 'THRESHOLD': 10, 'EIGHT_CONNECTEDNESS': True, 'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']
        poligonos = processing.run("gdal:polygonize", {
            'INPUT': binario_limpo, 'BAND': 1, 'FIELD': 'DN', 'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']

        poligonos_com_area = processing.run("native:fieldcalculator", {
            'INPUT': poligonos,
            'FIELD_NAME': 'area_ha',
            'FIELD_TYPE': 2, 
            'FORMULA': "substr(to_string($area / 10000), 1, strpos(to_string($area / 10000), '.') + 2)",
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }, context=context)['OUTPUT']
            
        final = processing.run("native:extractbyexpression", {
            'INPUT': poligonos_com_area, 'EXPRESSION': ' "DN" = 1 ', 'OUTPUT': parameters['OUTPUT']
        }, context=context)['OUTPUT']
        return {'OUTPUT': final}

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body><p>O algoritmo utiliza o índice <b>VARI</b> para identificar plantas daninhas em imagens RGB.</p>
        <p>Eficiência estimada entre <b>80% e 90%</b>.</p>
        <p>Nota: Os rasters devem estar recortados por talhão para otimizar o processamento.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic; border-top: 1px solid #ccc; padding-top: 10px;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p></body></html>"""

    def name(self): return 'plantas_daninhas'
    def displayName(self): return 'Identificação de Daninhas'
    def group(self): return 'Agricultura'
    def groupId(self): return 'agricultura'
    def createInstance(self): return IdentificacaoDaninhas()