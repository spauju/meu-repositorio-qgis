def classFactory(iface):
    from .agricultura_precisao_main import AgriculturaPrecisao
    return AgriculturaPrecisao(iface)