from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsWkbTypes
)
from PyQt5.QtCore import QVariant
import os


class CalculoAreaAgro(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                'INPUT',
                'Selecionar Polígonos',
                [QgsProcessing.TypeVectorPolygon]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                'OUTPUT',
                'Cálculo de área',
                createByDefault=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        source = self.parameterAsSource(parameters, 'INPUT', context)

        # Criar novos campos
        fields = source.fields()
        fields.append(QgsField('area_ha', QVariant.Double, len=10, prec=2))

        # Criar sink (isso resolve o TEMPORARY_OUTPUT!)
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            'OUTPUT',
            context,
            fields,
            source.wkbType(),
            source.sourceCrs()
        )

        for feat in source.getFeatures():
            geom = feat.geometry()
            area_ha = geom.area() / 10000

            new_feat = QgsFeature(fields)
            new_feat.setGeometry(geom)
            new_feat.setAttributes(feat.attributes() + [round(area_ha, 2)])

            sink.addFeature(new_feat)

        return {'OUTPUT': dest_id}

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Plugin para cálculo de área em hectares</p>
        <div style="text-align: center; margin: 20px 0;">
        <img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">
        Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def name(self):
        return 'calculo_area_agro'

    def displayName(self):
        return 'Cálculo de Área'

    def group(self):
        return 'Agricultura'

    def groupId(self):
        return 'agricultura'

    def createInstance(self):
        return CalculoAreaAgro()