from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsDistanceArea,
    QgsProject
)
from PyQt5.QtCore import QVariant
import os


class ComprimentoLinhasAgro(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                'INPUT',
                'Selecionar Linhas',
                [QgsProcessing.TypeVectorLine]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                'OUTPUT',
                'Comprimento das linhas',
                createByDefault=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        source = self.parameterAsSource(parameters, 'INPUT', context)

        # 🔥 Configuração correta de distância
        d = QgsDistanceArea()
        d.setSourceCrs(source.sourceCrs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        # Criar campos
        fields = source.fields()
        fields.append(QgsField('compriment', QVariant.Double, len=10, prec=2))

        # Criar saída temporária correta
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            'OUTPUT',
            context,
            fields,
            source.wkbType(),
            source.sourceCrs()
        )

        for feat in source.getFeatures():
            geom = feat.geometry()

            # 🔥 comprimento REAL em metros
            comprimento = d.measureLength(geom)

            new_feat = QgsFeature(fields)
            new_feat.setGeometry(geom)
            new_feat.setAttributes(feat.attributes() + [round(comprimento, 2)])

            sink.addFeature(new_feat)

        return {'OUTPUT': dest_id}

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Plugin para cálculo de comprimento de linhas em metros</p>
        <p>Calcula o comprimento real independente do CRS</p>
        <div style="text-align: center; margin: 20px 0;">
        <img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">
        Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def name(self):
        return 'comprimento_linhas'

    def displayName(self):
        return 'Comprimento de Linhas'

    def group(self):
        return 'Agricultura'

    def groupId(self):
        return 'agricultura'

    def createInstance(self):
        return ComprimentoLinhasAgro()