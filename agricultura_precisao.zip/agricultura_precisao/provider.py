import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

# Grupo: Agricultura de Precisão
from .plantas_daninhas import IdentificacaoDaninhas 
from .solo_exposto import SoloExposto 

# Grupo: Ferramentas de camadas
from .calculo_area_agro import CalculoAreaAgro
from .calculo_linhas_agro import CalculoLinhasAgro
from .comprimento_linhas_agro import ComprimentoLinhasAgro
from .simplifique import SimplificarLinhasAutoCAD
from .delete_duplicadas import RemoverDuplicadasTotal
from .copiar_estilo import CopiarEstiloAgro

class AgriculturaPrecisaoProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        # Estes aparecem na pasta principal "Agricultura de Precisão"
        self.addAlgorithm(IdentificacaoDaninhas())
        self.addAlgorithm(SoloExposto())

        # Estes aparecem na subpasta "Ferramentas de camadas"
        self.addAlgorithm(CalculoAreaAgro())
        self.addAlgorithm(CalculoLinhasAgro())
        self.addAlgorithm(ComprimentoLinhasAgro())
        self.addAlgorithm(SimplificarLinhasAutoCAD())
        self.addAlgorithm(RemoverDuplicadasTotal())
        self.addAlgorithm(CopiarEstiloAgro())

    def id(self): return 'agricultura_precisao'
    def name(self): return 'Agricultura de Precisão'
    def icon(self):
        path = os.path.join(os.path.dirname(__file__), 'icon.png')
        return QIcon(path)