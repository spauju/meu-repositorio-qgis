import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
# Importando todas as suas ferramentas
from .solo_exposto import SoloExposto 
from .calculo_area_agro import CalculoAreaAgro
from .calculo_linhas_agro import CalculoLinhasAgro
from .comprimento_linhas_agro import ComprimentoLinhasAgro
from .plantas_daninhas import IdentificacaoDaninhas 
# Nova ferramenta de simplificação:
from .simplifique import SimplificarLinhasAutoCAD

class AgriculturaPrecisaoProvider(QgsProcessingProvider):
    def __init__(self):
        QgsProcessingProvider.__init__(self)

    def unload(self):
        pass

    def loadAlgorithms(self):
        # Adicionando as ferramentas no provedor
        self.addAlgorithm(IdentificacaoDaninhas())
        self.addAlgorithm(SoloExposto())
        self.addAlgorithm(CalculoAreaAgro())
        self.addAlgorithm(CalculoLinhasAgro())
        self.addAlgorithm(ComprimentoLinhasAgro())
        # Registrando a nova ferramenta de simplificação
        self.addAlgorithm(SimplificarLinhasAutoCAD())

    def id(self):
        return 'agricultura_precisao'

    def name(self):
        return 'Agricultura de Precisão'

    def icon(self):
        path = os.path.join(os.path.dirname(__file__), 'icon.png')
        return QIcon(path)