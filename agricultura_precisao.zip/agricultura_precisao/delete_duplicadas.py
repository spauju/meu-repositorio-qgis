# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink, QgsFeatureSink, QgsProcessingException
)
import os

class RemoverDuplicadasTotal(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return RemoverDuplicadasTotal()

    def name(self):
        return 'remover_duplicadas_camadas'

    def displayName(self):
        return self.tr('Remover duplicadas')

    def group(self):
        return self.tr('Ferramentas de camadas')

    def groupId(self):
        return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Remove feições que possuem a mesma geometria e atributos.</b>.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT, self.tr('Camada de entrada'), [QgsProcessing.TypeVectorAnyGeometry]))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, self.tr('Camada limpa (sem duplicadas)')))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))

        fields = source.fields()
        (sink, dest_id) = self.parameterAsSink(parameters, self.OUTPUT, context, fields, source.wkbType(), source.sourceCrs())

        # Lista de nomes de campos de ID comuns para ignorar na comparação de "duplicidade"
        campos_ignorar = ['fid', 'id', 'objectid', 'pk', 'gid']
        indices_para_comparar = [i for i, field in enumerate(fields) if field.name().lower() not in campos_ignorar]

        feicoes_vistas = set()
        count = 0
        total = source.featureCount()

        for feat in source.getFeatures():
            if feedback.isCanceled():
                break

            # 1. Geometria como texto (WKT)
            geom_wkt = feat.geometry().asWkt() if feat.hasGeometry() else 'no_geom'
            
            # 2. Atributos (apenas os campos que não são IDs automáticos)
            attrs = feat.attributes()
            valores_comparacao = tuple(attrs[i] for i in indices_para_comparar)
            
            # Chave única: Geometria + Valores dos atributos significativos
            chave_identificadora = (geom_wkt, valores_comparacao)

            if chave_identificadora not in feicoes_vistas:
                feicoes_vistas.add(chave_identificadora)
                sink.addFeature(feat, QgsFeatureSink.FastInsert)
            
            count += 1
            feedback.setProgress(int(count * 100 / total))

        return {self.OUTPUT: dest_id}