# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink, QgsFeatureSink
)
import os

class RemoverDuplicadasTotal(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'

    def tr(self, string): return QCoreApplication.translate('Processing', string)
    def createInstance(self): return RemoverDuplicadasTotal()
    def name(self): return 'remover_duplicadas_camadas'
    def displayName(self): return self.tr('Remover duplicadas (Geometria + Atributos)')
    
    # Nova classe solicitada
    def group(self): return self.tr('Ferramentas de camadas')
    def groupId(self): return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Remove feições duplicadas comparando a <b>geometria exata</b> e <b>atributos</b>.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT, self.tr('Camada de entrada'), [QgsProcessing.TypeVectorAnyGeometry]))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, self.tr('Camada sem duplicadas')))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        (sink, dest_id) = self.parameterAsSink(parameters, self.OUTPUT, context, source.fields(), source.wkbType(), source.sourceCrs())
        vistos = set()
        for feat in source.getFeatures():
            if feedback.isCanceled(): break
            chave = (feat.geometry().asWkt() if feat.hasGeometry() else 'no_geom', tuple(feat.attributes()))
            if chave not in vistos:
                vistos.add(chave)
                sink.addFeature(feat, QgsFeatureSink.FastInsert)
        return {self.OUTPUT: dest_id}