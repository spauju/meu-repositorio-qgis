from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsWkbTypes
)
from PyQt5.QtCore import QVariant
import os


class CalculoAreaAgro(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                'INPUT',
                'Selecionar Polígonos',
                [QgsProcessing.TypeVectorPolygon]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                'OUTPUT',
                'Cálculo de área',
                createByDefault=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, 'INPUT', context)

        # 1. Primeiro passo: Calcular a soma total de todas as áreas
        total_soma_ha = 0
        for feat in source.getFeatures():
            geom = feat.geometry()
            total_soma_ha += (geom.area() / 10000)

        # 2. Criar novos campos (incluindo o novo campo de área total)
        fields = source.fields()
        fields.append(QgsField('area_ha', QVariant.Double, len=10, prec=2))
        fields.append(QgsField('area_ha_total', QVariant.Double, len=10, prec=2))

        # Criar sink
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            'OUTPUT',
            context,
            fields,
            source.wkbType(),
            source.sourceCrs()
        )

        # 3. Segundo passo: Gravar as feições com os cálculos individuais e o total
        for feat in source.getFeatures():
            geom = feat.geometry()
            area_ha_individual = geom.area() / 10000

            new_feat = QgsFeature(fields)
            new_feat.setGeometry(geom)
            
            # Adiciona os dois novos valores aos atributos existentes
            new_attributes = feat.attributes() + [round(area_ha_individual, 2), round(total_soma_ha, 2)]
            new_feat.setAttributes(new_attributes)

            sink.addFeature(new_feat)

        return {'OUTPUT': dest_id}

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Plugin para cálculo de área em hectares e somatório total</p>
        <div style="text-align: center; margin: 20px 0;">
        <img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">
        Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def name(self):
        return 'calculo_area_agro'

    def displayName(self):
        return 'Cálculo de Área'

    def group(self):
        return 'Agricultura'

    def groupId(self):
        return 'agricultura'

    def createInstance(self):
        return CalculoAreaAgro()