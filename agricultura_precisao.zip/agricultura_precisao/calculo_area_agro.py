# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink, QgsFields, QgsField, QgsFeature, 
    QgsDistanceArea, QgsUnitTypes, QgsProject
)
from PyQt5.QtCore import QVariant, QCoreApplication
import os

class CalculoAreaAgro(QgsProcessingAlgorithm):
    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return CalculoAreaAgro()

    def name(self):
        return 'calculo_area_agro'

    def displayName(self):
        return self.tr('Cálculo de área')

    def group(self):
        return self.tr('Ferramentas de camadas')

    def groupId(self):
        return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Calcula a área em hectares (ha) e o somatório total.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource('INPUT', self.tr('Selecionar Polígonos'), [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterFeatureSink('OUTPUT', self.tr('Resultado'), createByDefault=True))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, 'INPUT', context)
        d = QgsDistanceArea()
        d.setSourceCrs(source.sourceCrs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        features = list(source.getFeatures())
        total_soma_ha = sum([d.measureArea(f.geometry()) / 10000 for f in features])

        fields = source.fields()
        fields.append(QgsField('area_ha', QVariant.Double, len=10, prec=2))
        fields.append(QgsField('soma_total', QVariant.Double, len=10, prec=2))

        (sink, dest_id) = self.parameterAsSink(parameters, 'OUTPUT', context, fields, source.wkbType(), source.sourceCrs())

        for feat in features:
            if feedback.isCanceled(): break
            area_ha = d.measureArea(feat.geometry()) / 10000
            new_feat = QgsFeature(fields)
            new_feat.setGeometry(feat.geometry())
            new_feat.setAttributes(feat.attributes() + [round(area_ha, 2), round(total_soma_ha, 2)])
            sink.addFeature(new_feat)

        return {'OUTPUT': dest_id}