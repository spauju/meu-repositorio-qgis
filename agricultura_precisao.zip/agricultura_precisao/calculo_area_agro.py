from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsDistanceArea,
    QgsUnitTypes
)
from PyQt5.QtCore import QVariant
import os


class CalculoAreaAgro(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                'INPUT',
                'Selecionar Polígonos',
                [QgsProcessing.TypeVectorPolygon]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                'OUTPUT',
                'Cálculo de área',
                createByDefault=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, 'INPUT', context)
        
        # Configuração do calculador de distância e área
        d = QgsDistanceArea()
        d.setSourceCrs(source.sourceCrs(), context.transformContext())
        d.setEllipsoid(context.ellipsoid()) # Usa o elipsoide do projeto (ex: SIRGAS 2000/WGS 84)

        # 1. Primeiro passo: Calcular a soma total (usando medição elipsoidal)
        total_soma_ha = 0
        features = list(source.getFeatures())
        
        for feat in features:
            geom = feat.geometry()
            # measureArea retorna metros quadrados, dividimos por 10.000 para hectares
            area_m2 = d.measureArea(geom)
            total_soma_ha += (area_m2 / 10000)

        # 2. Preparar campos de saída
        fields = source.fields()
        fields.append(QgsField('area_ha', QVariant.Double, len=10, prec=2))
        fields.append(QgsField('area_ha_total', QVariant.Double, len=10, prec=2))

        (sink, dest_id) = self.parameterAsSink(
            parameters,
            'OUTPUT',
            context,
            fields,
            source.wkbType(),
            source.sourceCrs()
        )

        # 3. Segundo passo: Gravar feições com cálculos individuais
        for feat in features:
            geom = feat.geometry()
            area_ha_individual = d.measureArea(geom) / 10000

            new_feat = QgsFeature(fields)
            new_feat.setGeometry(geom)
            
            new_attributes = feat.attributes() + [round(area_ha_individual, 2), round(total_soma_ha, 2)]
            new_feat.setAttributes(new_attributes)

            sink.addFeature(new_feat)

        return {'OUTPUT': dest_id}

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Plugin para cálculo de área em hectares e somatório total.</p>
        <p><b>Nota:</b> O cálculo é realizado de forma elipsoidal, garantindo precisão mesmo em coordenadas geográficas (graus).</p>
        <div style="text-align: center; margin: 20px 0;">
        <img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">
        Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def name(self):
        return 'calculo_area_agro'

    def displayName(self):
        return 'Cálculo de Área (Hectares)'

    def group(self):
        return 'Agricultura'

    def groupId(self):
        return 'agricultura'

    def createInstance(self):
        return CalculoAreaAgro()