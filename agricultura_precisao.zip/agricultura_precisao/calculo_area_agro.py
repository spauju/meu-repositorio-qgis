# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer,
    QgsField, QgsDistanceArea, QgsProject, QgsProcessingException
)
from PyQt5.QtCore import QVariant, QCoreApplication
import os

class CalculoAreaAgro(QgsProcessingAlgorithm):
    INPUT = 'INPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return CalculoAreaAgro()

    def name(self):
        return 'calculo_area_agro'

    def displayName(self):
        return self.tr('Cálculo de área (Direto na Camada)')

    def group(self):
        return self.tr('Ferramentas de camadas')

    def groupId(self):
        return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Calcula a área em hectares (ha) e o somatório total <b>diretamente na camada selecionada</b>.</p>
        <p><i>Nota: Se houver feições selecionadas, apenas elas serão modificadas e somadas. Se não houver seleção, toda a camada será alterada.</i></p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        # Alterado para VectorLayer para permitir a edição direta
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT, self.tr('Selecionar Polígonos'), [QgsProcessing.TypeVectorPolygon]))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        if not layer:
            raise QgsProcessingException(self.tr('Camada inválida.'))

        # Configura o calculador de área oficial do projeto
        d = QgsDistanceArea()
        d.setSourceCrs(layer.sourceCrs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        # Verifica e cria os campos na camada se não existirem
        campos_para_adicionar = []
        if layer.fields().indexOf('area_ha') == -1:
            campos_para_adicionar.append(QgsField('area_ha', QVariant.Double, len=10, prec=2))
        if layer.fields().indexOf('soma_total') == -1:
            campos_para_adicionar.append(QgsField('soma_total', QVariant.Double, len=10, prec=2))

        if campos_para_adicionar:
            layer.dataProvider().addAttributes(campos_para_adicionar)
            layer.updateFields()

        # Recarrega os índices dos campos atualizados
        idx_area = layer.fields().indexOf('area_ha')
        idx_soma = layer.fields().indexOf('soma_total')

        # Filtra se há feições selecionadas ou usa todas
        features = list(layer.selectedFeatures()) if layer.selectedFeatureCount() > 0 else list(layer.getFeatures())
        total = len(features)

        # Calcula a soma total em hectares apenas do grupo que será editado
        total_soma_ha = sum([d.measureArea(f.geometry()) / 10000 for f in features if f.geometry() and not f.geometry().isEmpty()])

        # Inicia a edição direta de atributos na camada
        layer.startEditing()
        try:
            for i, feat in enumerate(features):
                if feedback.isCanceled():
                    break
                
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    area_ha = round(d.measureArea(geom) / 10000, 2)
                    
                    # Atualiza os atributos diretamente no ID da feição correspondente
                    layer.changeAttributeValue(feat.id(), idx_area, area_ha)
                    layer.changeAttributeValue(feat.id(), idx_soma, round(total_soma_ha, 2))
                
                feedback.setProgress(int((i / total) * 100))
            
            layer.commitChanges()
        except Exception as e:
            layer.rollBack()
            raise QgsProcessingException(self.tr(f'Erro ao atualizar a camada: {str(e)}'))

        return {self.INPUT: layer.id()}