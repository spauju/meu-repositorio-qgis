# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer,
    QgsDistanceArea, QgsProject, QgsProcessingException, QgsField,
    QgsRuleBasedRenderer, QgsSymbol, QgsSimpleLineSymbolLayer
)
from PyQt5.QtCore import QVariant, QCoreApplication
from PyQt5.QtGui import QColor
import os

class ComprimentoLinhasAgro(QgsProcessingAlgorithm):
    INPUT = 'INPUT'

    def tr(self, string): return QCoreApplication.translate('Processing', string)
    def createInstance(self): return ComprimentoLinhasAgro()
    def name(self): return 'comprimento_linhas'
    def displayName(self): return self.tr('Comprimento das linhas (Direto na Camada)')
    def group(self): return self.tr('Ferramentas de camadas')
    def groupId(self): return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Cálculo de comprimento real em metros aplicado <b>diretamente na camada selecionada</b>.</p>
        <p>Após o cálculo, a camada é <b>estilizada automaticamente</b> com base em regras de tamanho.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        # Alterado para VectorLayer para editar a própria camada selecionada
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT, self.tr('Selecionar Linhas'), [QgsProcessing.TypeVectorLine]))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        if not layer:
            raise QgsProcessingException(self.tr('Camada inválida.'))

        # Configura o calculador de distância/área do projeto
        d = QgsDistanceArea()
        d.setSourceCrs(layer.sourceCrs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        # Verifica se o campo 'compriment' já existe, caso contrário, cria-o
        field_name = 'compriment'
        field_idx = layer.fields().indexOf(field_name)
        
        if field_idx == -1:
            # Cria o campo na estrutura da camada
            layer.dataProvider().addAttributes([QgsField(field_name, QVariant.Double, len=10, prec=2)])
            layer.updateFields()
            field_idx = layer.fields().indexOf(field_name)

        # Identifica se há seleção ativa
        features = layer.selectedFeatures() if layer.selectedFeatureCount() > 0 else layer.getFeatures()
        total = layer.selectedFeatureCount() if layer.selectedFeatureCount() > 0 else layer.featureCount()

        # Inicia a edição direta na camada
        layer.startEditing()
        try:
            for i, feat in enumerate(features):
                if feedback.isCanceled():
                    break
                
                # Mede a geometria e calcula o comprimento
                comprimento = round(d.measureLength(feat.geometry()), 2)
                
                # Atualiza o atributo direto na feição pelo ID
                layer.changeAttributeValue(feat.id(), field_idx, comprimento)
                feedback.setProgress(int((i / total) * 100))
            
            layer.commitChanges()
        except Exception as e:
            layer.rollBack()
            raise QgsProcessingException(self.tr(f'Erro ao atualizar feições: {str(e)}'))

        # --- APLICAÇÃO DA SIMBOLIZAÇÃO AUTOMÁTICA (Baseada em Regras) ---
        feedback.pushInfo(self.tr("Aplicando estilização automatizada..."))
        
        # Definição das regras conforme a imagem fornecida (Rótulo, Expressão, Cor em formato HEX)
        regras_config = [
            ("0-100", '"compriment" < 101', "#ff834d"),        # Laranja claro
            ("101-200", '"compriment" >= 101 and "compriment" < 201', "#e6e600"), # Amarelo
            ("201-300", '"compriment" >= 201 and "compriment" < 301', "#4ea700"), # Verde
            ("301-400", '"compriment" >= 301 and "compriment" < 401', "#0070ff"), # Azul escuro
            ("401-500", '"compriment" >= 401 and "compriment" < 501', "#ff73df"), # Rosa/Magenta
            ("501-600", '"compriment" >= 501 and "compriment" < 601', "#e60000"), # Vermelho
            ("601-700", '"compriment" >= 601 and "compriment" < 701', "#4ce6ff"), # Azul claro / Ciano
            ("701-800", '"compriment" >= 701 and "compriment" < 801', "#8400a8"), # Roxo
            ("801-900", '"compriment" >= 801 and "compriment" < 901', "#0023f5"), # Azul Royal
            ("Acima de 900", '"compriment" >= 901', "#a87000") # Marrom / Oliva escuro
        ]

        # Cria a raiz do renderizador baseado em regras
        root_rule = QgsRuleBasedRenderer.Rule(QgsSymbol.defaultSymbol(layer.geometryType()))
        
        for rotulo, expressao, cor_hex in regras_config:
            # Cria o símbolo de linha padrão para a regra
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            symbol.setColor(QColor(cor_hex))
            
            # Ajusta a largura da linha para melhor visualização (padrão 0.4)
            if symbol.symbolLayerCount() > 0:
                symbol.symbolLayer(0).setWidth(0.4)
                
            # Cria a regra específica e adiciona à raiz
            rule = QgsRuleBasedRenderer.Rule(symbol, filterExp=expressao, label=rotulo)
            root_rule.appendChild(rule)

        # Remove a regra genérica inicial para ficar apenas com as nossas personalizadas
        renderer = QgsRuleBasedRenderer(root_rule)
        layer.setRenderer(renderer)
        
        # Força a atualização visual do mapa no QGIS
        layer.triggerRepaint()

        return {self.INPUT: layer.id()}