# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink, QgsFields, QgsField, QgsFeature, 
    QgsDistanceArea, QgsProject
)
from PyQt5.QtCore import QVariant, QCoreApplication
import os

class ComprimentoLinhasAgro(QgsProcessingAlgorithm):
    def tr(self, string): return QCoreApplication.translate('Processing', string)
    def createInstance(self): return ComprimentoLinhasAgro()
    def name(self): return 'comprimento_linhas'
    def displayName(self): return self.tr('Comprimento das linhas')
    def group(self): return self.tr('Ferramentas de camadas')
    def groupId(self): return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Cálculo de comprimento real em metros.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource('INPUT', self.tr('Selecionar Linhas'), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSink('OUTPUT', self.tr('Resultado'), createByDefault=True))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, 'INPUT', context)
        d = QgsDistanceArea()
        d.setSourceCrs(source.sourceCrs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        fields = source.fields()
        fields.append(QgsField('compriment', QVariant.Double, len=10, prec=2))

        (sink, dest_id) = self.parameterAsSink(parameters, 'OUTPUT', context, fields, source.wkbType(), source.sourceCrs())

        for feat in source.getFeatures():
            if feedback.isCanceled(): break
            comprimento = d.measureLength(feat.geometry())
            new_feat = QgsFeature(fields)
            new_feat.setGeometry(feat.geometry())
            new_feat.setAttributes(feat.attributes() + [round(comprimento, 2)])
            sink.addFeature(new_feat)

        return {'OUTPUT': dest_id}