# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, 
    QgsProcessingAlgorithm, 
    QgsProcessingParameterVectorLayer,
    QgsProcessingException,
    QgsGeometry,
    QgsFeature
)
import os

class UnirPoligonosMesmaCamada(QgsProcessingAlgorithm):
    INPUT = 'INPUT'

    def tr(self, string): 
        return QCoreApplication.translate('Processing', string)
    
    def createInstance(self): 
        return UnirPoligonosMesmaCamada()
    
    def name(self): 
        return 'unir_poligonos_mesma_camada'
    
    def displayName(self): 
        return self.tr('Unir polígonos selecionados')
    
    def group(self): 
        return self.tr('Ferramentas de camadas')
    
    def groupId(self): 
        return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Este script une as feições selecionadas <b>diretamente na camada original</b>.</p>
        <p><b>Atenção:</b> Ele remove as feições originais e as substitui por uma única feição unida (Multipart). Recomenda-se ter um backup dos dados.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT, 
                self.tr('Selecionar Camada'), 
                [QgsProcessing.TypeVectorPolygon]
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)

        if layer is None:
            raise QgsProcessingException('Camada inválida.')

        # Pegar apenas as feições selecionadas
        selection = layer.selectedFeatures()
        
        if len(selection) < 2:
            feedback.pushInfo('Selecione ao menos duas feições para unir.')
            return {'SAIDA': 'Nenhuma alteração feita.'}

        # Iniciar edição
        layer.startEditing()
        
        geometria_unida = QgsGeometry()
        ids_para_remover = []
        primeira_feicao = selection[0]

        feedback.pushInfo(f'Unindo {len(selection)} feições...')

        for feat in selection:
            if feedback.isCanceled():
                layer.rollBack()
                return {}

            if feat.hasGeometry():
                if geometria_unida.isNull():
                    geometria_unida = feat.geometry()
                else:
                    geometria_unida = geometria_unida.combine(feat.geometry())
            
            ids_para_remover.append(feat.id())

        # 1. Remover as feições antigas
        layer.deleteFeatures(ids_para_remover)

        # 2. Criar a nova feição com a geometria unida e atributos da primeira selecionada
        nova_feicao = QgsFeature(layer.fields())
        nova_feicao.setGeometry(geometria_unida)
        nova_feicao.setAttributes(primeira_feicao.attributes())
        
        layer.addFeature(nova_feicao)

        # O script deixa a camada em modo de edição para o usuário conferir e salvar
        feedback.pushInfo('Feições unidas com sucesso. Verifique a camada e salve as edições.')

        return {'SAIDA': f'{len(selection)} feições unidas em uma.'}