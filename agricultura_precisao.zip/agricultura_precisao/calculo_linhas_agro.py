# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink, QgsFields, QgsField, QgsFeature, 
    QgsDistanceArea, QgsProject
)
from PyQt5.QtCore import QVariant, QCoreApplication
import os

class CalculoLinhasAgro(QgsProcessingAlgorithm):
    def tr(self, string): return QCoreApplication.translate('Processing', string)
    def createInstance(self): return CalculoLinhasAgro()
    def name(self): return 'calculo_linhas_agro'
    def displayName(self): return self.tr('Cálculo de área linhas')
    def group(self): return self.tr('Ferramentas de camadas')
    def groupId(self): return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Fórmula: (Comprimento total × 2) / 8000</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource('INPUT', self.tr('Selecionar Linhas'), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSink('OUTPUT', self.tr('Resultado'), createByDefault=True))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, 'INPUT', context)
        d = QgsDistanceArea()
        d.setSourceCrs(source.sourceCrs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        comprimento_total = sum([d.measureLength(f.geometry()) for f in source.getFeatures()])
        area_ha = (comprimento_total * 2) / 8000

        fields = QgsFields()
        fields.append(QgsField('area_ha', QVariant.Double, len=10, prec=2))

        (sink, dest_id) = self.parameterAsSink(parameters, 'OUTPUT', context, fields, source.wkbType(), source.sourceCrs())
        feat = QgsFeature(fields)
        feat.setAttributes([round(area_ha, 2)])
        sink.addFeature(feat)

        return {'OUTPUT': dest_id}