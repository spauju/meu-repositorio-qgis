# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsProcessing, 
    QgsProcessingAlgorithm, 
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsFeatureSink,
    QgsGeometry,
    QgsFeature
)
import os

class RecortarPoligonoBuffer(QgsProcessingAlgorithm):
    POLIGONOS = 'POLIGONOS'
    LINHAS = 'LINHAS'
    OUTPUT = 'OUTPUT'

    def tr(self, string): 
        return QCoreApplication.translate('Processing', string)
    
    def createInstance(self): 
        return RecortarPoligonoBuffer()
    
    def name(self): 
        return 'recortar_poligono_buffer_individual'
    
    def displayName(self): 
        return self.tr('Recortar polígonos')
    
    def group(self): 
        return self.tr('Ferramentas de camadas')
    
    def groupId(self): 
        return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Este script recorta polígonos utilizando uma linha.</p>
        <p><b>Diferencial:</b> Se um polígono for dividido em dois ou mais pedaços, cada pedaço será salvo como uma <b>feição individual</b> (Singlepart) na tabela de atributos.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.POLIGONOS, 
                self.tr('Camada de Polígonos (Alvo)'), 
                [QgsProcessing.TypeVectorPolygon]
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.LINHAS, 
                self.tr('Camada de Linhas (Corte)'), 
                [QgsProcessing.TypeVectorLine]
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT, 
                self.tr('Polígonos Individuais Recortados')
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        source_poly = self.parameterAsSource(parameters, self.POLIGONOS, context)
        source_lines = self.parameterAsSource(parameters, self.LINHAS, context)

        if source_poly is None or source_lines is None:
            raise QgsProcessingException('Erro ao carregar as camadas de entrada.')

        # Sink configurado para a saída
        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context, 
            source_poly.fields(), source_poly.wkbType(), source_poly.sourceCrs()
        )

        # 1. Unir linhas e criar buffer de 0.01
        combined_lines_geom = QgsGeometry()
        for line_feat in source_lines.getFeatures():
            if line_feat.hasGeometry():
                if combined_lines_geom.isNull():
                    combined_lines_geom = line_feat.geometry()
                else:
                    combined_lines_geom = combined_lines_geom.combine(line_feat.geometry())
        
        if combined_lines_geom.isNull():
            raise QgsProcessingException('Nenhuma linha de corte válida encontrada.')

        buffer_geom = combined_lines_geom.buffer(0.01, 5)

        # 2. Processar polígonos
        total = source_poly.featureCount()
        for i, poly_feat in enumerate(source_poly.getFeatures()):
            if feedback.isCanceled():
                break

            geom = poly_feat.geometry()
            if geom and not geom.isEmpty():
                # Subtrai o buffer
                diff_geom = geom.difference(buffer_geom)
                
                # GARANTIR PEÇAS ÚNICAS (Singleparts)
                # Se a diferença gerou um MultiPolygon, transformamos em vários Polygons individuais
                if diff_geom.isMultipart():
                    parts = diff_geom.asGeometryCollection()
                    for part in parts:
                        new_feat = QgsFeature(poly_feat)
                        new_feat.setGeometry(part)
                        sink.addFeature(new_feat, QgsFeatureSink.FastInsert)
                else:
                    poly_feat.setGeometry(diff_geom)
                    sink.addFeature(poly_feat, QgsFeatureSink.FastInsert)

            feedback.setProgress(int(i / total * 100))

        return {self.OUTPUT: dest_id}