# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer
)
import os

class CopiarEstiloAgro(QgsProcessingAlgorithm):
    ORIGEM = 'ORIGEM'
    DESTINO = 'DESTINO'

    def tr(self, string): return QCoreApplication.translate('Processing', string)
    def createInstance(self): return CopiarEstiloAgro()
    def name(self): return 'copiar_estilo_camadas'
    def displayName(self): return self.tr('Copiar Estilo entre Camadas')
    
    # Nova classe solicitada
    def group(self): return self.tr('Ferramentas de camadas')
    def groupId(self): return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Copia a simbologia e rótulos de uma camada para outra.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(self.ORIGEM, self.tr('Camada de Origem'), [QgsProcessing.TypeVector]))
        self.addParameter(QgsProcessingParameterVectorLayer(self.DESTINO, self.tr('Camada de Destino'), [QgsProcessing.TypeVector]))

    def processAlgorithm(self, parameters, context, feedback):
        src = self.parameterAsVectorLayer(parameters, self.ORIGEM, context)
        dst = self.parameterAsVectorLayer(parameters, self.DESTINO, context)
        if src.renderer(): dst.setRenderer(src.renderer().clone())
        if src.labeling(): dst.setLabeling(src.labeling().clone())
        dst.triggerRepaint()
        return {self.DESTINO: dst.id()}