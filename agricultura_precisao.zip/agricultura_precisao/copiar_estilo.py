# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterMultipleLayers
)
import os


class CopiarEstiloAgro(QgsProcessingAlgorithm):

    ORIGEM = 'ORIGEM'
    DESTINOS = 'DESTINOS'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return CopiarEstiloAgro()

    def name(self):
        return 'copiar_estilo_camadas'

    def displayName(self):
        return self.tr('Copiar Estilo')

    # Grupo
    def group(self):
        return self.tr('Ferramentas de camadas')

    def groupId(self):
        return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(
            os.path.dirname(__file__),
            'icon.png'
        ).replace('\\', '/')

        return f"""<html><body>
        <p>Copia a simbologia e rótulos de uma camada para várias camadas.</p>

        <div style="text-align: center; margin: 20px 0;">
            <img src="file:///{icon_path}" width="250">
        </div>

        <p style="text-align: right; font-style: italic;">
            Desenvolvido por: <b>Paulo Vinicius da Silva</b>
        </p>
        </body></html>"""

    def initAlgorithm(self, config=None):

        # Camada origem
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.ORIGEM,
                self.tr('Camada de Origem'),
                [QgsProcessing.TypeVector]
            )
        )

        # Múltiplas camadas destino
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.DESTINOS,
                self.tr('Camadas de Destino'),
                layerType=QgsProcessing.TypeVector
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        src = self.parameterAsVectorLayer(
            parameters,
            self.ORIGEM,
            context
        )

        destinos = self.parameterAsLayerList(
            parameters,
            self.DESTINOS,
            context
        )

        total = len(destinos)

        if total == 0:
            feedback.pushInfo('Nenhuma camada de destino selecionada.')
            return {}

        for i, dst in enumerate(destinos, start=1):

            try:

                # Copia simbologia
                if src.renderer():
                    dst.setRenderer(src.renderer().clone())

                # Copia rótulos
                if src.labeling():
                    dst.setLabeling(src.labeling().clone())

                # Ativa rótulos se estiver ativo na origem
                dst.setLabelsEnabled(src.labelsEnabled())

                # Atualiza visualização
                dst.triggerRepaint()

                porcentagem = int((i / total) * 100)

                feedback.pushInfo(
                    f'[{porcentagem}%] Estilo aplicado em: {dst.name()}'
                )

            except Exception as e:

                feedback.pushInfo(
                    f'Erro ao aplicar em {dst.name()}: {str(e)}'
                )

        feedback.pushInfo('Processo concluído.')

        return {}