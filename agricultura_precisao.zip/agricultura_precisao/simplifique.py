# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer,
    QgsTopologyPreservingSimplifier, QgsProcessingException
)
import os

class SimplificarLinhasAutoCAD(QgsProcessingAlgorithm):
    INPUT = 'INPUT'

    def tr(self, string): return QCoreApplication.translate('Processing', string)
    def createInstance(self): return SimplificarLinhasAutoCAD()
    def name(self): return 'simplificar_linhas_camadas'
    def displayName(self): return self.tr('Simplificar linhas (Direto na Camada)')
    
    def group(self): return self.tr('Ferramentas de camadas')
    def groupId(self): return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Simplifica as linhas <b>diretamente na camada selecionada</b> utilizando o algoritmo de <b>Douglas-Peucker</b> com tolerância fixa de 0.010.</p>
        <p><i>Nota: Se houver feições selecionadas, apenas elas serão modificadas. Se não houver seleção, toda a camada será alterada.</i></p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT, self.tr('Camada de linhas'), [QgsProcessing.TypeVectorLine]))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        
        if not layer:
            raise QgsProcessingException(self.tr('Camada inválida.'))

        tol = 0.010
        simplificador = QgsTopologyPreservingSimplifier(tol)

        features = list(layer.selectedFeatures()) if layer.selectedFeatureCount() > 0 else list(layer.getFeatures())
        total = len(features)
        
        # Abre a camada para edição de forma explícita e segura
        layer.startEditing()
        try:
            for i, feat in enumerate(features):
                if feedback.isCanceled():
                    break
                
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    nova_geom = simplificador.simplify(geom)
                    # Atualiza a geometria diretamente na camada usando o ID da feição
                    layer.changeGeometry(feat.id(), nova_geom)
                
                feedback.setProgress(int((i / total) * 100))
            
            # Salva as alterações feitas direto no arquivo
            layer.commitChanges()
            
        except Exception as e:
            # Se der qualquer erro no processo, cancela e desfaz para não estragar seu arquivo
            layer.rollBack()
            raise QgsProcessingException(self.tr(f'Erro ao editar a camada: {str(e)}'))

        return {self.INPUT: layer.id()}