# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterNumber, QgsProcessingParameterFeatureSink,
    QgsTopologyPreservingSimplifier, QgsFeatureSink, QgsProcessingException
)
import os

class SimplificarLinhasAutoCAD(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    TOLERANCIA = 'TOLERANCIA'
    OUTPUT = 'OUTPUT'

    def tr(self, string): return QCoreApplication.translate('Processing', string)
    def createInstance(self): return SimplificarLinhasAutoCAD()
    def name(self): return 'simplificar_linhas_camadas'
    def displayName(self): return self.tr('Simplificar linhas (Padrão AutoCAD)')
    
    # Nova classe solicitada
    def group(self): return self.tr('Ferramentas de camadas')
    def groupId(self): return 'camadas'

    def shortHelpString(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Simplifica linhas utilizando o algoritmo de <b>Douglas-Peucker</b>.</p>
        <div style="text-align: center; margin: 20px 0;"><img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT, self.tr('Camada de linhas'), [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterNumber(self.TOLERANCIA, self.tr('Tolerância'), defaultValue=0.01))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, self.tr('Linhas simplificadas')))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        tol = self.parameterAsDouble(parameters, self.TOLERANCIA, context)
        (sink, dest_id) = self.parameterAsSink(parameters, self.OUTPUT, context, source.fields(), source.wkbType(), source.sourceCrs())
        simplificador = QgsTopologyPreservingSimplifier(tol)
        for feat in source.getFeatures():
            if feedback.isCanceled(): break
            geom = feat.geometry()
            if geom and not geom.isEmpty():
                feat.setGeometry(simplificador.simplify(geom))
            sink.addFeature(feat, QgsFeatureSink.FastInsert)
        return {self.OUTPUT: dest_id}