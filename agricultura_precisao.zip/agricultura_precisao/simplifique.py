# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFeatureSink,
    QgsTopologyPreservingSimplifier,
    QgsFeatureSink,
    QgsProcessingException,
    QgsWkbTypes
)
import os

class SimplificarLinhasAutoCAD(QgsProcessingAlgorithm):
    """
    Simplifica linhas preservando a topologia.
    Tolerância padrão 0.01 (estilo AutoCAD).
    """

    INPUT = 'INPUT'
    TOLERANCIA = 'TOLERANCIA'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return SimplificarLinhasAutoCAD()

    def name(self):
        return 'simplificarlinhasautocad_v2'

    def displayName(self):
        return self.tr('Simplificar linhas (padrão AutoCAD) v2')

    def group(self):
        return self.tr('Ferramentas de simplificação')

    def groupId(self):
        return 'simplificacao'

    def shortHelpString(self):
        # Busca o ícone na mesma pasta do script
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png').replace('\\', '/')
        return f"""<html><body>
        <p>Simplifica linhas utilizando o algoritmo de Douglas-Peucker com preservação de topologia.</p>
        <p>A <b>Tolerância</b> utiliza a unidade do CRS da camada (metros se for UTM).</p>
        <div style="text-align: center; margin: 20px 0;">
        <img src="file:///{icon_path}" width="250"></div>
        <p style="text-align: right; font-style: italic;">
        Desenvolvido por: <b>Paulo Vinicius da Silva</b></p>
        </body></html>"""

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr('Camada de linhas'),
                [QgsProcessing.TypeVectorLine]
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.TOLERANCIA,
                self.tr('Tolerância de simplificação'),
                QgsProcessingParameterNumber.Double,
                defaultValue=0.01,
                minValue=0.0
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr('Linhas simplificadas')
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))

        tolerancia = self.parameterAsDouble(parameters, self.TOLERANCIA, context)

        fields = source.fields()
        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            fields, source.wkbType(), source.sourceCrs()
        )
        
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        simplificador = QgsTopologyPreservingSimplifier(tolerancia)

        total = source.featureCount()
        if total == 0:
            return {self.OUTPUT: dest_id}

        count = 0
        for feat in source.getFeatures():
            if feedback.isCanceled():
                break

            geom = feat.geometry()
            if geom and not geom.isEmpty():
                try:
                    nova_geom = simplificador.simplify(geom)
                    feat.setGeometry(nova_geom)
                except Exception as e:
                    feedback.reportError(f"Erro ao simplificar feição {feat.id()}: {e}")
                    continue

            sink.addFeature(feat, QgsFeatureSink.FastInsert)
            count += 1
            feedback.setProgress(int(count / total * 100))

        return {self.OUTPUT: dest_id}